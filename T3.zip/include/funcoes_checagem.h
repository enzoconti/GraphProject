#ifndef __CHECAGEM_H__
#define __CHECAGEM_H__

#include "topologiaRede.h"
#include "funcoes_de_print.h"

int checa_consistencia(reg_cabecalho*);
int checa_consistencia_indice(reg_cabecalho_arvore*);
int checa_consistencia_grafo(reg_cabecalho*);
int checa_remocao(reg_dados*);

#endif